package pkg

fun main(args: Array<String>) {
    println(Java.getGreeting())
}
